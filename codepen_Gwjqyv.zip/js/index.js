function myF() {
document.getElementById("1").innerHTML= "hi" }